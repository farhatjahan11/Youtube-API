package com.funinmotiontoys.activities

import android.content.Intent
import android.databinding.DataBindingUtil
import android.graphics.Typeface
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import com.androidquery.AQuery
import com.funinmotiontoys.dataobject.VideoItemList
import com.funinmotiontoys.spinballsvideoapp.R
import com.funinmotiontoys.spinballsvideoapp.databinding.ActivityYoutubePlayerBinding
import com.funinmotiontoys.utils.Constants
import com.funinmotiontoys.utils.Utility
import com.google.android.youtube.player.YouTubeBaseActivity
import com.google.android.youtube.player.YouTubeInitializationResult
import com.google.android.youtube.player.YouTubePlayer
import com.google.android.youtube.player.YouTubePlayerView

/**
 * Created by farhat.
 */

class YouTubePlayerActivity : YouTubeBaseActivity(), YouTubePlayer.OnInitializedListener, View.OnClickListener {
    private var youTubeView: YouTubePlayerView? = null
    private var mTitleView: TextView? = null
    private var mDescriptionView: TextView? = null
    private var mSelectedMedia: VideoItemList? = null
    private var mAuthorView: TextView? = null
    private var mDownload: TextView? = null
    private var mfullScreen: TextView? = null
    private var mLeftArrow: TextView? = null
    private var mRightArrow: TextView? = null
    private var mFont: Typeface? = null
    private var mRemoveFile: TextView? = null
    private lateinit var utilty: Utility
    private lateinit var binding: ActivityYoutubePlayerBinding

    private val youTubePlayerProvider: YouTubePlayer.Provider?
        get() = youTubeView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_youtube_player)

        mFont = Typeface.createFromAsset(assets, Constants.ValueNames.FONT_DIRECTORY)
        val bundle = intent.extras
        if (bundle != null) {
            mSelectedMedia = VideoItemList.fromBundle(intent.getBundleExtra(Constants.KeyNames.MEDIA))
        }

        loadViews()
        initializeViews()
    }

    override fun onInitializationSuccess(provider: YouTubePlayer.Provider, player: YouTubePlayer, wasRestored: Boolean) {

        if (!wasRestored) {
            player.cueVideo("2v9Dp1H59Ek") // Plays https://www.youtube.com/watch?v=fhWaJi1Hsfo
        }
    }

    override fun onInitializationFailure(provider: YouTubePlayer.Provider, errorReason: YouTubeInitializationResult) {
        if (errorReason.isUserRecoverableError) {
            errorReason.getErrorDialog(this, RECOVERY_REQUEST).show()
        } else {
            Toast.makeText(this, getString(R.string.youtubeerror), Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent) {
        if (requestCode == RECOVERY_REQUEST) {
            youTubePlayerProvider!!.initialize(Constants.ApiKey.YOUTUBE_API_KEY, this)
        }
    }


    private fun loadViews() {

        youTubeView = findViewById<View>(R.id.youtube_view) as YouTubePlayerView
        youTubeView!!.initialize(Constants.ApiKey.YOUTUBE_API_KEY, this)
        mTitleView = findViewById<View>(R.id.textView1) as TextView
        mDescriptionView = findViewById<View>(R.id.textView2) as TextView
        mDescriptionView!!.movementMethod = ScrollingMovementMethod()
        mAuthorView = findViewById<View>(R.id.textView3) as TextView
        mDownload = findViewById<View>(R.id.downloadlink) as TextView
        mfullScreen = findViewById<View>(R.id.fullscreen) as TextView
        mRemoveFile = findViewById<View>(R.id.removefile) as TextView
        mLeftArrow = findViewById<View>(R.id.left_video) as TextView
        mRightArrow = findViewById<View>(R.id.right_video) as TextView

        mRemoveFile!!.typeface = mFont
        mDownload!!.typeface = mFont
        mLeftArrow!!.typeface = mFont
        mRightArrow!!.typeface = mFont
        mLeftArrow!!.setOnClickListener(this)
        mRightArrow!!.setOnClickListener(this)

    }


    private fun initializeViews() {
        utilty = Utility(this)
        utilty.changeStatusBarColor(this, Constants.ResponseConstants.PRIMARY_COLOR)
        utilty.setBackGroundGradient(binding.layoutMain!!, Constants.ResponseConstants.PRIMARY_COLOR, Constants.ResponseConstants.SECONDARY_COLOR)
    }


    override fun onClick(view: View) {
        when (view.id) {
            R.id.left_video -> {
            }
            R.id.right_video -> {
                val youtubeplayer1 = Intent(this@YouTubePlayerActivity, VideoPlayerActivity2::class.java)
                startActivity(youtubeplayer1)
            }
        }
    }

    companion object {
        private val RECOVERY_REQUEST = 1
    }
}
